package com.lab5.lab5;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.paint.Color;
import javafx.util.Duration;

public class HelloController {

    @FXML
    private Label timerLabel;

    @FXML
    private Label sessionLabel;

    @FXML
    private ProgressIndicator progressIndicator;

    @FXML
    private Button startPauseBtn;

    @FXML
    private Button resetBtn;

    @FXML
    private TextField workDurationField;

    @FXML
    private TextField shortBreakField;

    @FXML
    private TextField longBreakField;

    @FXML
    private CheckBox darkModeToggle;

    private Timeline timeline;

    private boolean running = false;

    private int workDuration;       // seconds
    private int shortBreakDuration; // seconds
    private int longBreakDuration;  // seconds

    private int timeLeft;           // seconds left in current session

    private int cyclesCompleted = 0;

    private SessionType currentSession = SessionType.WORK;

    enum SessionType { WORK, SHORT_BREAK, LONG_BREAK }

    @FXML
    public void initialize() {
        loadDurationsFromFields();

        updateTimerLabel(timeLeft);
        progressIndicator.setProgress(0);

        startPauseBtn.setOnAction(e -> {
            if (running) {
                pauseTimer();
            } else {
                startTimer();
            }
        });

        resetBtn.setOnAction(e -> resetTimer());

        darkModeToggle.selectedProperty().addListener((obs, oldV, newV) -> {
            if (newV) {
                timerLabel.getScene().getRoot().setStyle("-fx-background-color: #222; -fx-text-fill: white;");
                timerLabel.setTextFill(Color.WHITE);
                sessionLabel.setTextFill(Color.LIGHTGRAY);
            } else {
                timerLabel.getScene().getRoot().setStyle("");
                timerLabel.setTextFill(Color.BLACK);
                sessionLabel.setTextFill(Color.BLACK);
            }
        });

        // Update durations if user changes text fields
        workDurationField.textProperty().addListener((obs, oldV, newV) -> loadDurationsFromFields());
        shortBreakField.textProperty().addListener((obs, oldV, newV) -> loadDurationsFromFields());
        longBreakField.textProperty().addListener((obs, oldV, newV) -> loadDurationsFromFields());
    }

    private void loadDurationsFromFields() {
        try {
            workDuration = Math.max(1, Integer.parseInt(workDurationField.getText())) * 60;
            shortBreakDuration = Math.max(1, Integer.parseInt(shortBreakField.getText())) * 60;
            longBreakDuration = Math.max(1, Integer.parseInt(longBreakField.getText())) * 60;
        } catch (NumberFormatException e) {
            workDuration = 25 * 60;
            shortBreakDuration = 5 * 60;
            longBreakDuration = 20 * 60;
        }
        if (!running) {
            if (currentSession == SessionType.WORK)
                timeLeft = workDuration;
            else if (currentSession == SessionType.SHORT_BREAK)
                timeLeft = shortBreakDuration;
            else
                timeLeft = longBreakDuration;
            updateTimerLabel(timeLeft);
            progressIndicator.setProgress(0);
        }
    }

    private void startTimer() {
        running = true;
        startPauseBtn.setText("Pause");

        if (timeline != null) timeline.stop();

        timeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
            timeLeft--;
            updateTimerLabel(timeLeft);
            updateProgress();

            if (timeLeft <= 0) {
                switchSession();
            }
        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    private void pauseTimer() {
        running = false;
        startPauseBtn.setText("Start");
        if (timeline != null) timeline.stop();
    }

    private void resetTimer() {
        pauseTimer();
        cyclesCompleted = 0;
        currentSession = SessionType.WORK;
        timeLeft = workDuration;
        sessionLabel.setText("Work Session");
        updateTimerLabel(timeLeft);
        progressIndicator.setProgress(0);
    }

    private void updateTimerLabel(int seconds) {
        int min = seconds / 60;
        int sec = seconds % 60;
        timerLabel.setText(String.format("%02d:%02d", min, sec));
    }

    private void updateProgress() {
        int total;
        switch (currentSession) {
            case WORK -> total = workDuration;
            case SHORT_BREAK -> total = shortBreakDuration;
            case LONG_BREAK -> total = longBreakDuration;
            default -> total = workDuration;
        }
        double progress = 1.0 - (double) timeLeft / total;
        progressIndicator.setProgress(progress);
    }

    private void switchSession() {
        if (timeline != null) timeline.stop();

        if (currentSession == SessionType.WORK) {
            cyclesCompleted++;
            if (cyclesCompleted % 4 == 0) {
                currentSession = SessionType.LONG_BREAK;
                timeLeft = longBreakDuration;
                sessionLabel.setText("Long Break");
            } else {
                currentSession = SessionType.SHORT_BREAK;
                timeLeft = shortBreakDuration;
                sessionLabel.setText("Short Break");
            }
        } else {
            currentSession = SessionType.WORK;
            timeLeft = workDuration;
            sessionLabel.setText("Work Session");
        }
        updateTimerLabel(timeLeft);
        progressIndicator.setProgress(0);

        if (running) startTimer();
    }
}
