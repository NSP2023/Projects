package weather.lab7_220041120;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class WeatherModel {

    // Fields for current weather
    private String city;
    private String country; // ✅ New field for country
    private double temperature;
    private double feelsLike;
    private String conditionText;
    private int humidity;
    private double windSpeed;
    private String iconUrl;
    private String localTime;  // Added field for local time

    // Air Quality field
    private String airQuality;

    // Lists for forecast and history
    private List<DailyWeather> forecastDays;
    private List<DailyWeather> historyDays;

    // Constructor
    public WeatherModel() {
        this.forecastDays = new ArrayList<>();
        this.historyDays = new ArrayList<>();
    }

    // Nested class for daily weather summary
    public static class DailyWeather {
        private final LocalDate date;
        private final double maxTemp;
        private final double minTemp;
        private final String conditionText;
        private final String iconUrl;

        public DailyWeather(LocalDate date, double maxTemp, double minTemp, String conditionText, String iconUrl) {
            this.date = date;
            this.maxTemp = maxTemp;
            this.minTemp = minTemp;
            this.conditionText = conditionText;
            this.iconUrl = iconUrl;
        }

        public LocalDate getDate() { return date; }
        public double getMaxTemp() { return maxTemp; }
        public double getMinTemp() { return minTemp; }
        public String getConditionText() { return conditionText; }
        public String getIconUrl() { return iconUrl; }
    }

    // Getters for current weather
    public String getCity() { return city; }
    public String getCountry() { return country; }
    public double getTemperature() { return temperature; }
    public double getFeelsLike() { return feelsLike; }
    public String getConditionText() { return conditionText; }
    public int getHumidity() { return humidity; }
    public double getWindSpeed() { return windSpeed; }
    public String getIconUrl() { return iconUrl; }
    public String getLocalTime() { return localTime; }

    // Getter and setter for air quality
    public String getAirQuality() { return airQuality; }
    public void setAirQuality(String airQuality) { this.airQuality = airQuality; }

    // Getters for forecast and history
    public List<DailyWeather> getForecastDays() { return forecastDays; }
    public List<DailyWeather> getHistoryDays() { return historyDays; }

    // Parse current weather JSON, including air quality, country, and local time
    public static WeatherModel fromJson(String json) {
        WeatherModel model = new WeatherModel();

        JsonObject root = JsonParser.parseString(json).getAsJsonObject();
        JsonObject location = root.getAsJsonObject("location");
        JsonObject current = root.getAsJsonObject("current");
        JsonObject condition = current.getAsJsonObject("condition");

        model.city = location.get("name").getAsString();
        model.country = location.get("country").getAsString();
        model.localTime = location.get("localtime").getAsString();

        model.temperature = current.get("temp_c").getAsDouble();
        model.feelsLike = current.get("feelslike_c").getAsDouble();
        model.conditionText = condition.get("text").getAsString();
        model.humidity = current.get("humidity").getAsInt();
        model.windSpeed = current.get("wind_kph").getAsDouble();
        model.iconUrl = "https:" + condition.get("icon").getAsString();

        // Parse air quality if present
        if (current.has("air_quality")) {
            JsonObject airQualityObj = current.getAsJsonObject("air_quality");
            System.out.println("Air Quality JSON: " + airQualityObj.toString());  // DEBUG LOG

            if (airQualityObj.has("us-epa-index")) {
                int aqiIndex = airQualityObj.get("us-epa-index").getAsInt();
                model.airQuality = interpretAQI(aqiIndex);
            } else {
                model.airQuality = "Unknown (us-epa-index missing)";
            }
        } else {
            System.out.println("No air_quality field found in JSON");  // DEBUG LOG
            model.airQuality = "Not available";
        }

        return model;
    }

    // Parse forecast JSON (e.g. 3-day forecast)
    public static WeatherModel fromForecastJson(String json) {
        WeatherModel model = new WeatherModel();

        JsonObject root = JsonParser.parseString(json).getAsJsonObject();
        JsonObject location = root.getAsJsonObject("location");
        model.city = location.get("name").getAsString();
        model.country = location.get("country").getAsString();

        JsonArray forecastArray = root.getAsJsonObject("forecast").getAsJsonArray("forecastday");

        for (int i = 0; i < forecastArray.size(); i++) {
            JsonObject dayObj = forecastArray.get(i).getAsJsonObject();
            LocalDate date = LocalDate.parse(dayObj.get("date").getAsString());
            JsonObject day = dayObj.getAsJsonObject("day");

            double maxTemp = day.get("maxtemp_c").getAsDouble();
            double minTemp = day.get("mintemp_c").getAsDouble();
            JsonObject condition = day.getAsJsonObject("condition");
            String conditionText = condition.get("text").getAsString();
            String iconUrl = "https:" + condition.get("icon").getAsString();

            model.forecastDays.add(new DailyWeather(date, maxTemp, minTemp, conditionText, iconUrl));
        }

        return model;
    }

    // Parse historical JSON (e.g. 7-day history, one API call per day)
    public static WeatherModel fromHistoryJson(String json) {
        WeatherModel model = new WeatherModel();

        JsonObject root = JsonParser.parseString(json).getAsJsonObject();
        JsonObject location = root.getAsJsonObject("location");
        model.city = location.get("name").getAsString();
        model.country = location.get("country").getAsString();

        JsonArray forecastArray = root.getAsJsonObject("forecast").getAsJsonArray("forecastday");

        for (int i = 0; i < forecastArray.size(); i++) {
            JsonObject dayObj = forecastArray.get(i).getAsJsonObject();
            LocalDate date = LocalDate.parse(dayObj.get("date").getAsString());
            JsonObject day = dayObj.getAsJsonObject("day");

            double maxTemp = day.get("maxtemp_c").getAsDouble();
            double minTemp = day.get("mintemp_c").getAsDouble();
            JsonObject condition = day.getAsJsonObject("condition");
            String conditionText = condition.get("text").getAsString();
            String iconUrl = "https:" + condition.get("icon").getAsString();

            model.historyDays.add(new DailyWeather(date, maxTemp, minTemp, conditionText, iconUrl));
        }

        return model;
    }

    // Helper method to convert US EPA AQI index to readable string
    private static String interpretAQI(int aqiIndex) {
        switch (aqiIndex) {
            case 1: return "Good";
            case 2: return "Moderate";
            case 3: return "Unhealthy for Sensitive Groups";
            case 4: return "Unhealthy";
            case 5: return "Very Unhealthy";
            case 6: return "Hazardous";
            default: return "Unknown";
        }
    }
}
