package weather.lab7_220041120;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDate;

public class WeatherAPIClient {

    private static final String API_KEY = "27b4f9f1ffd149fb899124507251708";

    // Get current weather JSON as String
    public static String getWeather(String city) throws Exception {
        String endpoint = "http://api.weatherapi.com/v1/current.json?key=" + API_KEY + "&q=" + city + "&aqi=yes";

        return getResponseFromEndpoint(endpoint);
    }

    // Get current weather with air quality JSON as String
    public static String getWeatherWithAirQuality(String city) throws Exception {
        String endpoint = "http://api.weatherapi.com/v1/current.json?key=" + API_KEY + "&q=" + city + "&aqi=yes";
        return getResponseFromEndpoint(endpoint);
    }

    // Get weather forecast JSON for N days
    public static String getForecast(String city, int days) throws Exception {
        String endpoint = "http://api.weatherapi.com/v1/forecast.json?key=" + API_KEY + "&q=" + city + "&days=" + days;
        return getResponseFromEndpoint(endpoint);
    }

    // Get weather forecast JSON for the next 3 days
    public static String get3DayForecast(String city) {
        try {
            return getForecast(city, 3);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Get weather history JSON for a specific date
    public static String getWeatherHistory(String city, LocalDate date) throws Exception {
        String endpoint = "http://api.weatherapi.com/v1/history.json?key=" + API_KEY + "&q=" + city + "&dt=" + date.toString();
        return getResponseFromEndpoint(endpoint);
    }

    // Helper method to perform HTTP GET request and return response as String
    private static String getResponseFromEndpoint(String endpoint) throws Exception {
        URL url = new URL(endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        // Check for HTTP response code
        int responseCode = conn.getResponseCode();
        if (responseCode != HttpURLConnection.HTTP_OK) {
            throw new Exception("HTTP request failed with code " + responseCode);
        }

        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;

        while ((line = reader.readLine()) != null) {
            response.append(line);
        }

        reader.close();
        return response.toString();
    }

    // Wrapper method to parse current weather JSON into WeatherModel
    public static WeatherModel getCurrentWeather(String city) {
        try {
            String json = getWeather(city);
            return WeatherModel.fromJson(json);  // Make sure to implement fromJson() in WeatherModel
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Wrapper method to parse current weather with air quality JSON into WeatherModel
    public static WeatherModel getCurrentWeatherWithAirQuality(String city) {
        try {
            String json = getWeatherWithAirQuality(city);
            return WeatherModel.fromJson(json);  // Update fromJson() to handle air quality
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Optional: wrapper for weather history JSON (return JSON string here, parsed later)
    public static String getWeatherHistoryRaw(String city, LocalDate date) {
        try {
            return getWeatherHistory(city, date);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
