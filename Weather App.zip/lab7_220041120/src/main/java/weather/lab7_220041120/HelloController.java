package weather.lab7_220041120;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.control.Alert;
import javafx.scene.layout.Pane;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class HelloController {

    @FXML private TextField cityTextField;
    @FXML private Button searchButton;
    @FXML private Label cityLabel;
    @FXML private Label tempLabel;
    @FXML private Label feelsLikeLabel;
    @FXML private Label conditionLabel;
    @FXML private Label humidityLabel;
    @FXML private Label windLabel;
    @FXML private ImageView weatherIcon;
    @FXML private AnchorPane rootPane;
    @FXML private TextArea historyTextArea;
    @FXML private Label dateTimeLabel;
    @FXML private Label countryLabel;


    // Grids for visual display
    @FXML private HBox forecastGrid;
    @FXML private HBox pastForecastGrid;
    @FXML private Pane infoCard;
    @FXML
    private Label airQualityLabel;


    @FXML
    protected void onSearchButtonClick() {
        String city = cityTextField.getText().trim();

        if (city.isEmpty()) {
            cityLabel.setText("Please enter a city name.");
            clearWeatherData();
            dateTimeLabel.setText("");
            return;
        }

        WeatherModel model = WeatherAPIClient.getCurrentWeatherWithAirQuality(city);


        if (model != null) {
            cityLabel.setText(model.getCity());
            countryLabel.setText(model.getCountry());
            tempLabel.setText(model.getTemperature() + "°C");
            feelsLikeLabel.setText(model.getFeelsLike() + "°C");
            conditionLabel.setText(model.getConditionText());
            humidityLabel.setText(model.getHumidity() + "%");
            windLabel.setText(model.getWindSpeed() + "kph");

            Image image = new Image(model.getIconUrl(), true);
            weatherIcon.setImage(image);

            loadPast3DaysForecast(city);
            loadFuture3DaysForecast(city);
            applyWeatherStyle(model.getConditionText().toLowerCase());

            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy HH:mm");
            dateTimeLabel.setText(now.format(formatter));

            String airQuality = model.getAirQuality();
            airQualityLabel.setText((airQuality == null || airQuality.isEmpty()) ? "Air Quality: N/A" : "" + airQuality);
            applyAirQualityStyle(airQuality);
        } else {
            showInvalidCityAlert();
            clearWeatherData();
            dateTimeLabel.setText("");
        }
    }




        private void applyAirQualityStyle(String airQuality) {
        if (airQuality == null) {
            airQualityLabel.setStyle("-fx-text-fill: gray;");
            return;
        }
        switch (airQuality.toLowerCase()) {
            case "good":
                airQualityLabel.setStyle("-fx-text-fill: green;");
                break;
            case "moderate":
                airQualityLabel.setStyle("-fx-text-fill: orange;");
                break;
            case "unhealthy":
            case "poor":
                airQualityLabel.setStyle("-fx-text-fill: red;");
                break;
            default:
                airQualityLabel.setStyle("-fx-text-fill: black;");
                break;
        }
    }


    private void showInvalidCityAlert() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Invalid City/County");
        alert.setHeaderText(null);
        alert.setContentText("Invalid City/ County");
        alert.showAndWait();
    }

    private void clearWeatherData() {
        tempLabel.setText("");
        feelsLikeLabel.setText("");
        conditionLabel.setText("");
        humidityLabel.setText("");
        windLabel.setText("");
        forecastGrid.getChildren().clear();
        pastForecastGrid.getChildren().clear();
        historyTextArea.clear();
        rootPane.getStyleClass().removeAll("sunny", "rainy", "thunderstorm", "gloomy", "snow", "dry");
    }

    @FXML
    private void applyWeatherStyle(String condition) {
        rootPane.getStyleClass().removeAll(
                "sunny", "rainy", "thunderstorm", "gloomy", "snow", "dry",
                "light-text", "dark-text"
        );

        String cardColor = "#d0abe080"; // Default color with 50% opacity
        boolean isDark = false;

        if (condition.contains("sunny")) {
            rootPane.getStyleClass().add("sunny");
            cardColor = "#e0b93d80";
            isDark = false;
        } else if (condition.contains("clear")) {
            rootPane.getStyleClass().add("sunny");
            cardColor = "#ffb75880";
            isDark = false;
        } else if (condition.contains("rain")) {
            rootPane.getStyleClass().add("rainy");
            cardColor = "#3544b5";  // Strong blue for rain
            isDark = true;
        } else if (condition.contains("thunderstorm")) {
            rootPane.getStyleClass().add("thunderstorm");
            cardColor = "#5a829680";
            isDark = true;
        } else if (condition.contains("cloudy") || condition.contains("gloomy") || condition.contains("overcast")) {
            rootPane.getStyleClass().add("gloomy");
            cardColor = "#67a7db80";
            isDark = false;
        } else if (condition.contains("snow")) {
            rootPane.getStyleClass().add("snow");
            cardColor = "#e0e0e080";
            isDark = true;
        } else if (condition.contains("dry")) {
            rootPane.getStyleClass().add("dry");
            cardColor = "#cce08980";
            isDark = false;
        }

        // Update infoCard background
        infoCard.setStyle("-fx-background-color: " + cardColor + "; -fx-background-radius: 10;");

        // Text contrast
        if (isDark) {
            rootPane.getStyleClass().add("light-text");
        } else {
            rootPane.getStyleClass().add("dark-text");
        }
    }

    private void loadPast3DaysForecast(String city) {
        try {
            pastForecastGrid.getChildren().clear();
            LocalDate today = LocalDate.now();

            for (int i = 1; i <= 3; i++) {
                LocalDate date = today.minusDays(i);
                String json = WeatherAPIClient.getWeatherHistory(city, date);

                if (json == null || json.isEmpty()) {
                    continue;
                }

                JsonObject rootObj = JsonParser.parseString(json).getAsJsonObject();
                JsonObject forecastDay = rootObj.getAsJsonObject("forecast")
                        .getAsJsonArray("forecastday")
                        .get(0).getAsJsonObject();

                JsonObject day = forecastDay.getAsJsonObject("day");
                double avgTempC = day.get("avgtemp_c").getAsDouble();
                String conditionText = day.getAsJsonObject("condition").get("text").getAsString();
                String iconUrl = "https:" + day.getAsJsonObject("condition").get("icon").getAsString();

                // Create card
                VBox dayBox = new VBox(5);
                dayBox.setAlignment(Pos.CENTER);
                dayBox.setPrefWidth(110);
                dayBox.setStyle("-fx-background-color: #5a5a5a; -fx-background-radius: 10; -fx-padding: 10;");

                Label dateLabel = new Label(date.toString());
                dateLabel.setTextFill(Color.WHITE);

                ImageView icon = new ImageView(new Image(iconUrl, true));
                icon.setFitWidth(40);
                icon.setFitHeight(40);

                Label tempLabel = new Label(String.format("Avg: %.1f°C", avgTempC));
                tempLabel.setTextFill(Color.WHITE);

                Label condLabel = new Label(conditionText);
                condLabel.setTextFill(Color.WHITE);
                condLabel.setWrapText(true);
                condLabel.setStyle("-fx-font-size: 11px;");
                condLabel.setMaxWidth(90);

                dayBox.getChildren().addAll(dateLabel, icon, tempLabel, condLabel);
                pastForecastGrid.getChildren().add(dayBox);
            }

        } catch (Exception e) {
            e.printStackTrace();
            pastForecastGrid.getChildren().clear();
        }
    }

    private void loadFuture3DaysForecast(String city) {
        try {
            String json = WeatherAPIClient.get3DayForecast(city);

            if (json == null || json.isEmpty()) {
                forecastGrid.getChildren().clear();
                return;
            }

            JsonObject root = JsonParser.parseString(json).getAsJsonObject();
            JsonObject forecast = root.getAsJsonObject("forecast");

            forecastGrid.getChildren().clear();

            for (int i = 0; i < 3; i++) {
                JsonObject dayObj = forecast.getAsJsonArray("forecastday").get(i).getAsJsonObject();
                String date = dayObj.get("date").getAsString();
                JsonObject day = dayObj.getAsJsonObject("day");

                double avgTemp = day.get("avgtemp_c").getAsDouble();
                String condition = day.getAsJsonObject("condition").get("text").getAsString();
                String iconUrl = "https:" + day.getAsJsonObject("condition").get("icon").getAsString();

                VBox dayBox = new VBox(5);
                dayBox.setAlignment(Pos.CENTER);
                dayBox.setPrefWidth(110);
                dayBox.setStyle("-fx-background-color: #3e3e8a; -fx-background-radius: 10; -fx-padding: 10;");

                Label dateLabel = new Label(date);
                dateLabel.setTextFill(Color.WHITE);

                ImageView icon = new ImageView(new Image(iconUrl, true));
                icon.setFitWidth(40);
                icon.setFitHeight(40);

                Label tempLabel = new Label(String.format("Avg: %.1f°C", avgTemp));
                tempLabel.setTextFill(Color.WHITE);

                Label condLabel = new Label(condition);
                condLabel.setTextFill(Color.WHITE);
                condLabel.setWrapText(true);
                condLabel.setStyle("-fx-font-size: 11px;");
                condLabel.setMaxWidth(90);

                dayBox.getChildren().addAll(dateLabel, icon, tempLabel, condLabel);
                forecastGrid.getChildren().add(dayBox);
            }

        } catch (Exception e) {
            e.printStackTrace();
            forecastGrid.getChildren().clear();
        }
    }
}
