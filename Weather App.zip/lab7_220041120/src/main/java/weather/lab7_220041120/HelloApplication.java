package weather.lab7_220041120;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.net.URL;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) {
        try {
            // Load FXML
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            AnchorPane rootPane = fxmlLoader.load(); // Casting to AnchorPane to access rootPane directly

            // Create Scene
            Scene scene = new Scene(rootPane);

            // Load CSS stylesheet
            URL cssUrl = getClass().getResource("styles.css");
            if (cssUrl != null) {
                scene.getStylesheets().add(cssUrl.toExternalForm());
            } else {
                System.out.println("⚠️ styles.css not found. Please check the path.");
            }

            // Set initial weather class (default background color)
            rootPane.getStyleClass().add("sunny"); // Change this dynamically later in your controller

            // Set up the Stage
            stage.setTitle("Weather App");
            stage.setScene(scene);
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("❌ Failed to start application. Check FXML and CSS paths.");
        }
    }

    public static void main(String[] args) {
        launch();
    }
}
