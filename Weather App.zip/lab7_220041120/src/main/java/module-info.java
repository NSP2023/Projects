module weather.lab7_220041120 {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.json;
    requires com.google.gson;


    opens weather.lab7_220041120 to javafx.fxml;
    exports weather.lab7_220041120;
}
