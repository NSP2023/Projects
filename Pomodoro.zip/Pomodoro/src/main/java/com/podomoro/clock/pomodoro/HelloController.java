package com.podomoro.clock.pomodoro;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;

import java.io.File;

public class HelloController {

    @FXML private Label timerLabel;
    @FXML private Button startButton, pauseButton, resetButton;
    @FXML private ProgressBar progressBar;
    @FXML private TextField workTextField, shortBreakTextField, longBreakTextField;
    @FXML private ComboBox<String> themeComboBox;
    @FXML private AnchorPane rootPane;

    private Timeline timeline;
    private int totalSeconds;
    private int currentSeconds;
    private int sessionCount = 0;
    private boolean isRunning = false;
    private boolean isWorkTime = true;

    private final String soundPath = "C:\\Users\\User\\Downloads\\Pomodoro\\src\\main\\resources\\com\\podomoro\\clock\\pomodoro\\birds_sound.mp3";

    @FXML
    public void initialize() {
        themeComboBox.getItems().addAll("Light", "Dark");
        themeComboBox.setValue("Dark");
        applyTheme("Dark");

        // Start with default durations
        setDurationsFromInput();
        startNewSession();
    }

    private void setDurationsFromInput() {
        // Called to update durations from text fields
        double workMin = getInput(workTextField, 25);
        double shortBreakMin = getInput(shortBreakTextField, 5);
        double longBreakMin = getInput(longBreakTextField, 20);

        // Convert minutes to seconds
        workDurationSeconds = (int) Math.round(workMin * 60);
        shortBreakSeconds = (int) Math.round(shortBreakMin * 60);
        longBreakSeconds = (int) Math.round(longBreakMin * 60);
    }

    private int workDurationSeconds = 25 * 60;
    private int shortBreakSeconds = 5 * 60;
    private int longBreakSeconds = 20 * 60;

    private void startNewSession() {
        if (isWorkTime) {
            totalSeconds = workDurationSeconds;
        } else {
            totalSeconds = (sessionCount % 4 == 0) ? longBreakSeconds : shortBreakSeconds;
        }
        currentSeconds = totalSeconds;
        updateTimerLabel();
        progressBar.setProgress(0);
    }

    private double getInput(TextField field, double defaultValue) {
        try {
            double val = Double.parseDouble(field.getText());
            return val > 0 ? val : defaultValue;
        } catch (Exception e) {
            return defaultValue;
        }
    }

    @FXML
    public void onStart() {
        if (isRunning) return;

        // Update durations every time Start is pressed (picks up fresh input)
        setDurationsFromInput();

        // If timer just reset or finished, start a new session with updated times
        if (currentSeconds == 0 || !isRunning) {
            startNewSession();
        }

        timeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
            currentSeconds--;
            updateTimerLabel();
            progressBar.setProgress(1 - (double) currentSeconds / totalSeconds);

            if (currentSeconds <= 0) {
                timeline.stop();
                isRunning = false;

                isWorkTime = !isWorkTime;
                if (isWorkTime) {
                    sessionCount++;
                } else {
                    playBreakSound();
                }

                startNewSession();
                onStart(); // auto-start next session
            }
        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
        isRunning = true;
    }

    private void playBreakSound() {
        try {
            Media sound = new Media(new File(soundPath).toURI().toString());
            MediaPlayer mediaPlayer = new MediaPlayer(sound);
            mediaPlayer.play();
        } catch (Exception e) {
            System.err.println("Error playing sound: " + e.getMessage());
        }
    }

    @FXML
    public void onPause() {
        if (timeline != null) timeline.stop();
        isRunning = false;
    }

    @FXML
    public void onReset() {
        if (timeline != null) timeline.stop();
        isRunning = false;
        isWorkTime = true;
        sessionCount = 0;

        setDurationsFromInput();  // make sure durations reset from input fields
        startNewSession();
    }

    private void updateTimerLabel() {
        int minutes = currentSeconds / 60;
        int seconds = currentSeconds % 60;
        timerLabel.setText(String.format("%02d:%02d", minutes, seconds));
    }

    @FXML
    public void onThemeChange() {
        String selected = themeComboBox.getValue();
        applyTheme(selected);
    }

    private void applyTheme(String theme) {
        if ("Light".equals(theme)) {
            rootPane.setStyle("-fx-background-color: #f0f0f0;");
            timerLabel.setStyle("-fx-text-fill: black; -fx-font-size: 60px;");
        } else {
            rootPane.setStyle("-fx-background-color: #1e1e1e;");
            timerLabel.setStyle("-fx-text-fill: white; -fx-font-size: 60px;");
        }
    }
}
