module com.podomoro.clock.pomodoro {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.media; // ✅ Required for MediaPlayer

    opens com.podomoro.clock.pomodoro to javafx.fxml;
    exports com.podomoro.clock.pomodoro;
}
