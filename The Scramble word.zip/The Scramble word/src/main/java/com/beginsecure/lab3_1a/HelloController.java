package com.beginsecure.lab3_1a;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import java.util.*;

public class HelloController {
    @FXML
    private HBox letterBox;

    private  List<String> wordList = new ArrayList<>(List.of("IUT", "Lab-3", "JavaFx", "Failure", "Success", "CAR", "BAT", "ROAD"));
    private String currentWord;
    private  StringBuilder userGuess = new StringBuilder();
    private int wordIndex = 0;

    private int score = 0;              // Track score
    private int attempt = 0;            // Current attempt count
    private  int max_attempt=4;  // Max attempts (per word)

    public void initialize() {
        Collections.shuffle(wordList);
        score = 0;
        wordIndex = 0;
        loadNextWord();
    }

    public void loadNextWord() {
        if (wordIndex >= wordList.size()) {
            Show("Congratulations!","Your score is: " + score + "/" + wordList.size());
            HelloApplication.restartGame();
            return;
        }

        attempt = 0;  //attempt reset for new word
        userGuess.setLength(0);
        letterBox.getChildren().clear();

        currentWord = wordList.get(wordIndex);
        List<Character> shuffledLetters = new ArrayList<>();
        for (char c : currentWord.toCharArray()) shuffledLetters.add(c);
        Collections.shuffle(shuffledLetters);

        for (char c : shuffledLetters) {
            Button btn = new Button(String.valueOf(c));
            btn.setMinSize(50, 50);
            btn.setOnAction(e -> handleLetterClick(btn));
            letterBox.getChildren().add(btn);
        }
    }

    private void handleLetterClick(Button btn) {
        userGuess.append(btn.getText());
        btn.setDisable(true);

        if (userGuess.length() == currentWord.length()) {
            if (userGuess.toString().equals(currentWord)) {
                score++;
                wordIndex++;
                Show("Correct!", "Good job!\nCurrent Score: " + score);
                loadNextWord();
            } else {
                attempt++;
                if (attempt >= max_attempt) {
                    Show("Try Again", "Incorrect! The correct word was: " + currentWord + "\nYour score: " + score + "\nGame will restart.");
                    HelloApplication.restartGame();
                } else {
                    Show("Incorrect!", "Wrong guess. Attempts left: " + (max_attempt - attempt));
                    resetCurrentWord();
                }
            }
        }
    }

    private void resetCurrentWord() {
        userGuess.setLength(0);
        letterBox.getChildren().forEach(node -> node.setDisable(false));  // enable button again
    }

    private void Show(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
