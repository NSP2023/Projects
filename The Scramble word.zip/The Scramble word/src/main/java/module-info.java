module com.beginsecure.lab3_1a {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.beginsecure.lab3_1a to javafx.fxml;
    exports com.beginsecure.lab3_1a;
}