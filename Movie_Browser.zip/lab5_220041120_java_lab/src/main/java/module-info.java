module movie_dashboard.lab5_220041120_java_lab {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    opens movie_dashboard.lab5_220041120_java_lab to javafx.fxml;
    exports movie_dashboard.lab5_220041120_java_lab;
}
