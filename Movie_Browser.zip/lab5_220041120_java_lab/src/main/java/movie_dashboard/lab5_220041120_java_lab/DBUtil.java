package movie_dashboard.lab5_220041120_java_lab;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
    private static final String URL = "jdbc:mysql://localhost:3306/moviesdb";
    private static final String USER = "root";
    private static final String PASSWORD = "NoshinSyara!23.";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
