package movie_dashboard.lab5_220041120_java_lab;

import java.util.List;

public class Movie {
    private int id;
    private String title;
    private int year;
    private double rating;
    private int votes;
    private String posterUrl;
    private List<String> genres;

    // Getters and setters
    // Constructor
}
