package movie_dashboard.lab5_220041120_java_lab;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.layout.Region;

import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;

public class HelloController {
    @FXML private FlowPane movieFlowPane;
    @FXML private TextField searchField;
    @FXML private ComboBox<String> genreComboBox;  // Added genre filter dropdown
    @FXML private ToggleButton themeToggle;
    @FXML private Button watchLaterButton;  // Optional separate Watch Later button

    private final List<Map<String, String>> allMovies = new ArrayList<>();
    private final Set<String> watchLaterList = new HashSet<>();
    private boolean isDarkTheme = false;

    @FXML
    public void initialize() {
        loadMoviesFromDatabase();
        setupGenreFilter();      // Initialize genre filter ComboBox
        applyTheme();            // Set default theme
        showMovies(allMovies);   // Show all movies initially
    }

    private void loadMoviesFromDatabase() {
        allMovies.clear();
        try (Connection conn = DBUtil.getConnection()) {
            String query = "SELECT * FROM movies";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Map<String, String> movie = new HashMap<>();
                movie.put("id", rs.getString("id"));
                movie.put("title", rs.getString("title"));
                movie.put("genre", rs.getString("genre"));
                movie.put("year", rs.getString("year"));
                movie.put("rating", rs.getString("rating"));
                movie.put("duration", rs.getString("duration"));
                movie.put("cast", rs.getString("cast"));
                movie.put("plot", rs.getString("plot"));
                movie.put("posterUrl", rs.getString("posterUrl"));
                allMovies.add(movie);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setupGenreFilter() {
        // Extract unique genres, splitting multiple genres separated by commas
        Set<String> genres = allMovies.stream()
                .map(m -> m.get("genre"))
                .filter(Objects::nonNull)
                .flatMap(g -> Arrays.stream(g.split(",\\s*")))
                .collect(Collectors.toSet());

        List<String> genreList = new ArrayList<>();
        genreList.add("All");  // Option to disable genre filtering
        genreList.addAll(genres.stream().sorted().collect(Collectors.toList()));

        genreComboBox.getItems().setAll(genreList);
        genreComboBox.getSelectionModel().selectFirst();  // Default select "All"

        // Add listeners to trigger filtering when search text or genre changes
        genreComboBox.setOnAction(e -> filterMovies());
        searchField.textProperty().addListener((obs, oldVal, newVal) -> filterMovies());
    }

    private void filterMovies() {
        String searchText = searchField.getText().toLowerCase();
        String selectedGenre = genreComboBox.getSelectionModel().getSelectedItem();

        List<Map<String, String>> filtered = allMovies.stream()
                .filter(m -> m.get("title").toLowerCase().contains(searchText))
                .filter(m -> {
                    if ("All".equals(selectedGenre)) return true;
                    String genreStr = m.get("genre");
                    if (genreStr == null) return false;
                    return Arrays.stream(genreStr.split(",\\s*"))
                            .anyMatch(g -> g.equalsIgnoreCase(selectedGenre));
                })
                .collect(Collectors.toList());

        showMovies(filtered);
    }

    private void showMovies(List<Map<String, String>> movieList) {
        movieFlowPane.getChildren().clear();
        for (Map<String, String> movie : movieList) {
            VBox card = createMovieCard(movie);
            movieFlowPane.getChildren().add(card);
        }
    }

    private VBox createMovieCard(Map<String, String> movie) {
        VBox card = new VBox(5);
        card.setPrefWidth(180);

        String cardStyle = isDarkTheme ?
                "-fx-background-color: #2c2c2c; -fx-text-fill: white;" :
                "-fx-background-color: white; -fx-text-fill: black;";

        card.setStyle(cardStyle + " -fx-padding: 10; -fx-border-radius: 10; -fx-background-radius: 10;" +
                " -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 4, 0, 0, 2);");

        ImageView poster;
        try {
            String posterUrl = movie.get("posterUrl");
            if (posterUrl == null || posterUrl.isEmpty()) throw new Exception("No poster URL");
            Image image = new Image(posterUrl, 160, 220, true, true, true);
            poster = new ImageView(image);
        } catch (Exception e) {
            poster = new ImageView(); // fallback empty ImageView
            poster.setFitWidth(160);
            poster.setFitHeight(220);
            poster.setStyle("-fx-background-color: gray;");  // Placeholder background
        }

        // Show details when poster clicked
        poster.setOnMouseClicked(e -> showMovieDetailDialog(movie));

        Label title = new Label(movie.get("title"));
        title.setWrapText(true);
        title.setStyle("-fx-font-weight: bold;" + (isDarkTheme ? " -fx-text-fill: white;" : " -fx-text-fill: black;"));

        Label genre = new Label(movie.get("genre"));
        genre.setStyle(isDarkTheme ? "-fx-text-fill: #ccc;" : "-fx-text-fill: gray;");

        Label rating = new Label("⭐ " + movie.get("rating"));
        rating.setStyle(isDarkTheme ? "-fx-text-fill: #ffeb3b;" : "-fx-text-fill: #555;");

        Button watchLaterBtn = new Button(watchLaterList.contains(movie.get("id")) ? "Remove" : "Watch Later");

        watchLaterBtn.setOnAction(e -> {
            String id = movie.get("id");
            if (watchLaterList.contains(id)) {
                watchLaterList.remove(id);
                watchLaterBtn.setText("Watch Later");
            } else {
                watchLaterList.add(id);
                watchLaterBtn.setText("Remove");
            }
        });

        card.getChildren().addAll(poster, title, genre, rating, watchLaterBtn);
        return card;
    }

    private void showMovieDetailDialog(Map<String, String> movie) {
        Alert dialog = new Alert(Alert.AlertType.INFORMATION);
        dialog.setTitle(movie.get("title"));
        dialog.setHeaderText("Duration: " + movie.get("duration") + " | Rating: " + movie.get("rating"));
        dialog.setContentText("Cast: " + movie.get("cast") + "\n\nPlot: " + movie.get("plot"));
        dialog.getDialogPane().setMinHeight(Region.USE_PREF_SIZE); // Allow scrolling if text is long
        dialog.showAndWait();
    }

    @FXML
    private void onSearch() {
        filterMovies();
    }

    @FXML
    private void toggleTheme() {
        isDarkTheme = themeToggle.isSelected();
        applyTheme();
        showMovies(allMovies);  // re-render movie cards with new theme
    }

    private void applyTheme() {
        if (movieFlowPane.getScene() != null) {
            String rootStyle = isDarkTheme
                    ? "-fx-base: #1e1e1e; -fx-background-color: #1e1e1e; -fx-text-fill: white;"
                    : "-fx-base: white; -fx-background-color: white; -fx-text-fill: black;";
            movieFlowPane.getScene().getRoot().setStyle(rootStyle);
        }
    }

    @FXML
    private void showWatchLater() {
        List<Map<String, String>> watchLaterMovies = allMovies.stream()
                .filter(m -> watchLaterList.contains(m.get("id")))
                .collect(Collectors.toList());
        showMovies(watchLaterMovies);
    }
}
